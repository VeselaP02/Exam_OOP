package goldDigger.repositories;

import goldDigger.models.spot.Spot;

import java.util.Collection;

public class SpotRepository implements Repository<Spot>{
    private Collection<Spot> spots;
    @Override
    public Collection<Spot> getCollection() {
        return null;
    }

    @Override
    public void add(Spot entity) {

    }

    @Override
    public boolean remove(Spot entity) {
        return false;
    }

    @Override
    public Spot byName(String name) {
        return null;
    }
}
