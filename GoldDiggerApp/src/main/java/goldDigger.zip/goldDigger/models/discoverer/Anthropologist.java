package goldDigger.models.discoverer;

public class Anthropologist extends BaseDiscoverer{
    private static final double energy = 40;

    public Anthropologist(String name) {
        super(name, energy);
    }
}
